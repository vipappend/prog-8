<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Progate</title>
  <link rel="stylesheet" type="text/css" href="stylesheet.css">
</head>
<body>

  <?php

    //この下に配列を作ってください
    $colors = array('赤','青','黄');
    echo $colors[0];
    $colors[] = '白';
    echo $colors[3];
  ?>

</body>
</html>
