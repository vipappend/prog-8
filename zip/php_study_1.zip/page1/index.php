<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Progate</title>
  <link rel="stylesheet" type="text/css" href="stylesheet.css">
</head>
<body>

  <?php
    //'Hello, world!'をechoしてください
    echo 'Hello, world!';
  ?>
  
  <br>

  <?php
    //7 * 2をechoしてください
    echo 7 * 2;
  ?>

  <br>

  <?php
    //8 % 3をechoしてください
    echo 8 % 3;
  ?>

</body>
</html>
