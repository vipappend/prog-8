<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Progate</title>
  <link rel="stylesheet" type="text/css" href="stylesheet.css">
</head>
<body>

  <?php

    $x = 99 * 99;

    $y = 77 * 77;

    // ここにif文を書いていきましょう
    if($x > 9800){
      echo '変数xは9800より大きいです。';
    }
    if($y > 6000){
      echo '変数yは6000より大きいです。';
    }
    
  ?>

</body>
</html>
