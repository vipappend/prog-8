<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Progate</title>
  <link rel="stylesheet" type="text/css" href="stylesheet.css">
</head>
<body>

  <?php

    //自分の名前を文字列にして入れてください。
    $name = '前田拓也';
    echo "こんにちは！$name"
  ?>

</body>
</html>
