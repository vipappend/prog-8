<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Progate</title>
  <link rel="stylesheet" type="text/css" href="stylesheet.css">
</head>
<body>

  <?php

    $age = 22;
    if($age >= 30){
      echo 'あなたは30歳以上です。';
    }else{
      echo 'あなたは30歳未満です。';
    }
  ?>

</body>
</html>
