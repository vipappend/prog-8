$(function() {
  // 変数titleに、「#title」要素のテキストを代入してください
  var title = $('#title').text();
  
  // textメソッドを用いて、「#title-text」要素のテキストを書き換えてください
  $('#title-text').text(title);
});